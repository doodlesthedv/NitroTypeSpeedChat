window.onload = function() {
    var chatContainer = document.createElement("article");
    chatContainer.className = "chat-container is-down";
    document.body.appendChild(chatContainer);
    chatContainer.innerHTML = `
    <div class = "menu">
        <div class = "show-hide-toggle one"> Chat </div>

        <main class = "hideable">
        <button class = "add-chat-btn"> 
            <span> + </span> 
        </button>

        <button class = "chat-id-container chat-id1 active-chat" data-chat-link = "https://minnit.chat/NitrotypeFastChat"> 
            <span class = "chat-id1">Chat</span>
        </button>

        </main>

       
    </div>

    <div class = "input-container off"> 
        <input type = "input" class = "chat-link-input" placeholder = "Chat link"> 
        <span class = "final-add-chat-btn"> Add Chat</span>
    </div>

    <iframe class = 'chat' src = 'https://minnit.chat/NitrotypeFastChat?embed&&nickname='> </iframe`;


    function e(elem) {
        return document.querySelector(elem);
    }

    function eA(elemA) {
        return document.querySelectorAll(elemA);
    }

    function ObjKeys(item) {
        return Object.keys(JSON.parse(localStorage.getItem(item)))
    }

    function getLocalStorageItem(item) {
        return JSON.parse(localStorage.getItem(item))
    }

    chat_container = document.querySelector(".chat-container");
    toggle_btn = document.querySelector(".show-hide-toggle");
    toggle_btn.addEventListener("click", toggle);
    var hideable = document.querySelector(".hideable");

    var final_add_chat_btn = document.querySelector(".final-add-chat-btn");

    var add_chat_btn = document.querySelector(".add-chat-btn");

    var chat_link_input;

    var input_container = document.querySelector(".input-container");
    var chat_id_containers;
    var iframe_elem;

    var recreatedChat;
    var retrievedItems;
    var deleteButtonCounter = 0;

    var i;
    var tm;

    var number_of_chats = 1;



    var chat_info = {

    }

    var localStorage = window.localStorage;
    if (localStorage.getItem("chat-info")) {

        if (ObjKeys("chat-info").length + 1 > 1) {
            number_of_chats = ObjKeys("chat-info").length + 1;

            recreateElements(changeIframe);
        }

    } else {
        number_of_chats = 1;
    }


    function recreateElements(callback) {
        var values = Object.values(JSON.parse(localStorage.getItem("chat-info")));


        if (number_of_chats <= 4) {

            for (var i = 1; i < number_of_chats; i++) {
                recreatedChatBtn = document.createElement("button");
                // create button for new chat
                recreatedChatBtn.className = "chat-id-container cic";


                recreatedChatBtn.setAttribute("data-chat-link", values[i - 1]);
                recreatedChatBtn.setAttribute("data-id", i);
                // ...
                recreatedChatBtn.innerHTML = "<span class = 'chat-id1'>ch" + [i] + "</span>";

                hideable.appendChild(recreatedChatBtn);

            }

            callback()
            configureDeleteButton();
        }
    }


    function toggle() {
        if (chat_container.className == "chat-container is-down") {
            showChat(addAnotherChat); // show chat

        } else if (chat_container.className == "chat-container is-up") {
            hideChat() // hide chat

        }
    }

    function showChat(callback) {
        chat_container.className = "chat-container is-up";
        toggle_btn.innerHTML = "⎯";

        document.querySelector(".hideable").style.display = "flex";
        callback();

    }

    function hideChat() {
        chat_container.className = "chat-container is-down";
        toggle_btn.innerHTML = "Chat";

        hideInputContainer();
    }

    function addAnotherChat() {
        chat_link_input = document.querySelector(".chat-link-input");
        add_chat_btn.addEventListener("click", goahead);

    }

    function hideInputContainer() {
        input_container.className = "input-container off";
        add_chat_btn.children[0].innerHTML = "+"
    }


    function goahead(gg) {
        gg.stopPropagation();
        if (localStorage.getItem("chat-info")) {
            number_of_chats = ObjKeys("chat-info").length + 1;
            chat_info = JSON.parse(localStorage.getItem("chat-info"));
            // alert(number_of_chats + "length now")
        }

        input_container = document.querySelector(".input-container");

        //alert(number_of_chats)
        if (input_container.className.includes("off") && number_of_chats < 4) { // yes < 4
            validateInput();
            showInputContainer();

        } else {
            hideInputContainer()
        }

        function showInputContainer() {
            input_container.className = "input-container on";
            add_chat_btn.children[0].innerHTML = "✕"
        }

        function validateInput() {
            chat_link_input.addEventListener("input", function() {
                if (chat_link_input.value.includes("minnit.chat/") == false) {
                    final_add_chat_btn.innerHTML = "Invalid link";
                } else {
                    final_add_chat_btn.innerHTML = "Add Chat";
                }
            })

            final_add_chat_btn.addEventListener("click", function() {
                if (chat_link_input.value.includes("minnit.chat/")) {
                    finallyAddChat();

                }
            })
        }



        final_add_chat_btn.removeEventListener("click", finallyAddChat)

    } //




    //}

    function finallyAddChat() {

        if (localStorage.getItem("chat-info")) {
            chat_info = JSON.parse(localStorage.getItem("chat-info"));
            number_of_chats = ObjKeys("chat-info").length + 1;
            // alert(number_of_chats + "number of chats -- inside")
        }

        var new_added_chat = document.createElement("button");

        if (number_of_chats <= 4) {
            // create button for new chat
            new_added_chat.className = "chat-id-container cic";
            new_added_chat.setAttribute("data-chat-link", chat_link_input.value)
            new_added_chat.setAttribute("data-id", number_of_chats)
            // ...
            new_added_chat.innerHTML = "<span class = 'chat-id1'>ch" + (number_of_chats) + "</span>";

            hideable.appendChild(new_added_chat);
            for (var i = 1; i < number_of_chats + 1; i++) {
                chat_info[i] = chat_link_input.value;
            }
            localStorage.setItem("chat-info", JSON.stringify(chat_info))
            changeIframe();

            configureDeleteButton()
        }

        hideInputContainer();

        function hideInputContainer() {
            chat_link_input.value = "";
            input_container.className = "input-container off";
            add_chat_btn.children[0].innerHTML = "+"
        }

        changeActiveChat();
        final_add_chat_btn.removeEventListener("click", finallyAddChat)
    }



    function changeIframe() {
        chat_id_containers = document.querySelectorAll(".chat-id-container");
        iframe_elem = document.querySelector(".chat");
        chat_id_containers.forEach(function(x) {
            x.addEventListener("click", function(event) {
                event.stopPropagation()
                iframe_elem.src = x.dataset.chatLink;
            });
        })
    }

    function configureDeleteButton() {


        chat_id_containers = document.querySelectorAll(".cic");
        chat_id_containers.forEach(function(x) {
            var time;
            x.addEventListener("mouseover", function(y) {
                y.stopPropagation();
                time = setTimeout(displayDeleteButton, 1000);

            });

            function displayDeleteButton() {

                if (e(".delete-button")) {
                    eA(".delete-button").forEach((delbtn) => {
                        delbtn.remove();
                    })
                }

                var deleteBtn = document.createElement("span");
                deleteBtn.className = "delete-button";
                deleteBtn.innerHTML = "Delete";

                x.appendChild(deleteBtn);

                delete_button = e(".delete-button"); // e = querySelec...

                delete_button.addEventListener("click", function(event) {
                    //event.stopPropagation()
                    deleteChat()

                });

                delete_button.addEventListener("mouseleave", function(event) {
                    event.target.remove();
                });

                clearTimeout(time);

            }

            x.addEventListener("mouseup", function() {
                clearTimeout(time);

            })

            x.addEventListener("mouseout", function() {
                clearTimeout(time)
            });

            function deleteChat() {
                var el = e(".delete-button").parentNode;
                var chosen_elem_id = Array.from(eA(".cic")).indexOf(el);
                var chosen_item = ObjKeys("chat-info")[chosen_elem_id]; //removed -1

                chat_info = JSON.parse(localStorage.getItem("chat-info"));

                delete chat_info[chosen_item]; // add 1
                // 
                localStorage.setItem("chat-info", JSON.stringify(chat_info))


                eA(".delete-button")[0].parentNode.remove();

                chat_info = JSON.parse(localStorage.getItem("chat-info"));

                function updateLocalStorage(key, value) {
                    chat_info[key] = value;
                }

                if (e(".cic")) {
                    for (var i = 0; i < Array.from(eA(".cic").length); i++) {
                        eA(".cic")[i].firstChlidElement.innerHTML = "ch" + [i];
                    }

                }
            }

        }) // foreach

    }

    changeActiveChat()

    function changeActiveChat() {

        var chats = eA(".chat-id-container");

        chats.forEach(function(x) {
            x.addEventListener("click", function() {
                var current = eA(".active-chat");
                if (current.length > 0) {
                    current[0].className = current[0].className.replace(" active-chat", "");
                }
                this.className += " active-chat";

            });
        })
    }



}